---
linkTitle: 高度な設定
title: 高度なトピック
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

このセクションでは、テーマの高度なトピックについて説明します。

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="多言語対応" icon="translate" >}}
  {{< card link="customization" title="カスタマイズ" icon="pencil" >}}
  {{< card link="comments" title="コメントシステム" icon="chat-alt" >}}
{{< /cards >}}