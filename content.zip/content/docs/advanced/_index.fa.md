---
linkTitle: پیشرفته
title: مباحث پیشرفته
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

این بخش برخی از مباحث پیشرفته این پوسته را پوشش می‌دهد.

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="چندزبانه" icon="translate" >}}
  {{< card link="customization" title="سفارشی‌سازی" icon="pencil" >}}
  {{< card link="comments" title="سیستم نظرات" icon="chat-alt" >}}
{{< /cards >}}