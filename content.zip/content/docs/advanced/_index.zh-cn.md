---
linkTitle: 高级
title: 高级主题
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

本节涵盖该主题的一些高级内容。

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="多语言支持" icon="translate" >}}
  {{< card link="customization" title="自定义配置" icon="pencil" >}}
  {{< card link="comments" title="评论系统" icon="chat-alt" >}}
{{< /cards >}}