﻿---
title: "Hello MainStruct"
date: 2025-08-19T00:00:00
draft: false
---

# 🎉 部署成功（本地测试页）

这是本地测试页面。如果你能看到这段文字，说明 Hugo 路由正常。
